<div id="footer">
    Sitio Web
</div>