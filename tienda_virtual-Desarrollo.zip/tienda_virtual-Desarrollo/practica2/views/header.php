<!DOCTYPE html>
<html lang="en">
<head>
    <title></title>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="public/css/default.css">
</head>
<body>
    <div id="header">
        <ul>
            <li><a href="main">Inicio</a></li>
            <li><a href="nuevo">Nuevo</a></li>
            <li><a href="consulta">Consulta</a></li>
            <li><a href="ayuda">Ayuda</a></li>
            <li><a href="#"></a></li>
        </ul>
    </div>
</body>
</html>