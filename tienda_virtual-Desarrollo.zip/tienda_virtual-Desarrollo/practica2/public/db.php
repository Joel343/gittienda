<?php
     $conexion = mysqli_connect('localhost','root','houston77.','db_tiendavirtual');
?>