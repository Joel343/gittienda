<?php
     $conexion = mysqli_connect('localhost','root','houston77.','tienda_online');
?>